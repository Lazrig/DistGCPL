#! /bin/sh

if [ "$1" -a "$2" ] ;
    then

	H=`sed '/^\#/d' config/jppf.properties | grep '1.jppf.server.host'  | tail -n 1 | cut -d "=" -f2- | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'`

	if [  $H ]; 
		then sed -i 's/\(1.jppf.server.host =\).*/\1 '$1'/' config/jppf.properties; 
	else 
		sed -i '26i driver1.jppf.server.host = '$1' ' config/jppf.properties ;
	fi 


	P=`sed '/^\#/d' config/jppf.properties | grep '1.jppf.server.port'  | tail -n 1 | cut -d "=" -f2- | sed 's/^[[:space:]]*//;s/[[:space:]]*$//'`

	if [  $H ]; 
		then sed -i 's/\(1.jppf.server.port =\).*/\1 '$2'/' config/jppf.properties; 
	else 
		sed -i '29i driver1.jppf.server.port = '$2' ' config/jppf.properties ;
	fi 
fi

