#! /bin/sh
rm -r AGent1/slave_nodes
rm -r AGent2/slave_nodes
rm -r AGent3/slave_nodes
rm -r AGent4/slave_nodes
rm -r AGent5/slave_nodes
rm -r AGent6/slave_nodes
