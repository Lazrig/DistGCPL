#! /bin/sh



if [ "$1" -a "$2" ] ;
    then
	./setMangOnHost.sh  "$1"  "$2"

	export JAVA_CP=config:build/classes:shared/lib/*:dist/lib/*
	export JVM_OPTS="-Xmx256m -Djppf.config=jppf.properties -Dlog4j.configuration=log4j.properties"

	#java -cp $JAVA_CP $JVM_OPTS patientlinkage.Util.Main -config configs/cfg_eva_4BFs_Blk_10k.txt -data BFData/Blkd_src_b_4BFs_10k.csv
	#
	java -cp $JAVA_CP $JVM_OPTS patientlinkage.Util.Main -config configs/cfg_eva_4BFs_Blk_140k.txt -data BFData/Blkd_src_b_4BFs_140k.csv



	#java -cp $JAVA_CP $JVM_OPTS patientlinkage.Util.Main -config configs/cfg_eva_4BFs_Blk_2k.txt -data BFData/Blkd_src_b_4BFs_2k.csv

else
	echo -e '\n' "!!!  Eval: YOU SHOULD SPECIFY the IP and PORT # of the DRIVER  that Will Work For me" '\n' 

fi
